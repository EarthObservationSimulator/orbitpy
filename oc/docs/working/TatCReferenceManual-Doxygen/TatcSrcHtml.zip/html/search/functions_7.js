var searchData=
[
  ['keyvaluestatistics',['KeyValueStatistics',['../class_key_value_statistics.html#af4d9fb6cf79b1bc6af86e21a9ea06d2d',1,'KeyValueStatistics::KeyValueStatistics(Real minVal, Real maxVal, Real avgVal)'],['../class_key_value_statistics.html#ad5091059660503d3c8771cc20c01dcdb',1,'KeyValueStatistics::KeyValueStatistics(const KeyValueStatistics &amp;copy)']]]
];
