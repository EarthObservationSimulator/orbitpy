var searchData=
[
  ['radectounitvec',['RADECtoUnitVec',['../class_sensor.html#a8efd7c8e0aa2a57079f8e6c976f5e15d',1,'Sensor']]],
  ['rectangularsensor',['RectangularSensor',['../class_rectangular_sensor.html#a860b22f49c30a9e1194a4c3c9b593720',1,'RectangularSensor::RectangularSensor(Real angleWidthIn, Real angleHeightIn)'],['../class_rectangular_sensor.html#a5958b786fd2d9a05147ceb66672cd4a0',1,'RectangularSensor::RectangularSensor(const RectangularSensor &amp;copy)']]],
  ['regionisfullycontained',['RegionIsFullyContained',['../class_custom_sensor.html#a0f3fb377ba3faf974bb7b2903b52d63e',1,'CustomSensor']]]
];
