var searchData=
[
  ['j2',['J2',['../class_earth.html#aff8ac0d3e83e2153e3caaf7070e6dcc1',1,'Earth::J2()'],['../class_propagator.html#a1bb80578f364bc89eed960933e5acae1',1,'Propagator::J2()']]],
  ['jd_5f1900',['JD_1900',['../class_absolute_date.html#afa2a3cf8b1534b9f7e45895df123b1f8',1,'AbsoluteDate']]]
];
