var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvxyz~",
  1: "aceiklnoprstv",
  2: "aceiklnoprstv",
  3: "acefghiklmnoprstuv~",
  4: "abcdefijlmnoprstvxyz",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

