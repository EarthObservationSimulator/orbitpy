var searchData=
[
  ['nadirpointingattitude',['NadirPointingAttitude',['../class_nadir_pointing_attitude.html#a483ef2d3b1cef7135267f905142fa9f7',1,'NadirPointingAttitude::NadirPointingAttitude()'],['../class_nadir_pointing_attitude.html#a85376bc0e6e904c679549a8310512d27',1,'NadirPointingAttitude::NadirPointingAttitude(const NadirPointingAttitude &amp;copy)']]]
];
