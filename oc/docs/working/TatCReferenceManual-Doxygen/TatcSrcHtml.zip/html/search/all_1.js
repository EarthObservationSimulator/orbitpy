var searchData=
[
  ['bfstate',['bfState',['../class_coverage_checker.html#ad007c6cfe102f9dc1e8a4f2dd2f1ec74',1,'CoverageChecker']]],
  ['body_5fradius',['BODY_RADIUS',['../class_coverage_checker.html#a45b747a131b998e37f1f493d50df161d',1,'CoverageChecker']]],
  ['bodyunit',['bodyUnit',['../class_coverage_checker.html#a1d78a9e4ac62f244ce05b37cd6d4d888',1,'CoverageChecker']]]
];
