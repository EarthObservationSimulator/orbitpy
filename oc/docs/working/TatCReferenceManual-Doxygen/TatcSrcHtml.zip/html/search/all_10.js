var searchData=
[
  ['r_5fbn',['R_BN',['../class_spacecraft.html#ac9c71a35dcbbab73227d37bc19beca25',1,'Spacecraft']]],
  ['r_5ffixed_5fto_5fnadir',['R_fixed_to_nadir',['../class_nadir_pointing_attitude.html#ae37cdb2b4d8fd79f090fe1ad80226e7c',1,'NadirPointingAttitude']]],
  ['r_5ffixed_5fto_5fnadir_5ftransposed',['R_fixed_to_nadir_transposed',['../class_nadir_pointing_attitude.html#a6f9e522105a0712fb78ee9f8cec4a8f7',1,'NadirPointingAttitude']]],
  ['r_5fsb',['R_SB',['../class_sensor.html#af82a62d8c853c09618e7ab6c27e05aa0',1,'Sensor']]],
  ['raan',['RAAN',['../class_propagator.html#a967a9a988ab51c8c3b4852fab37082c5',1,'Propagator']]],
  ['radectounitvec',['RADECtoUnitVec',['../class_sensor.html#a8efd7c8e0aa2a57079f8e6c976f5e15d',1,'Sensor']]],
  ['radius',['radius',['../class_earth.html#a9415a71c6b8918e252452b3b7bff2595',1,'Earth']]],
  ['rangevec',['rangeVec',['../class_coverage_checker.html#a22c5db93fbb4a025f6ee0a282e79ebfe',1,'CoverageChecker']]],
  ['rectangularsensor',['RectangularSensor',['../class_rectangular_sensor.html',1,'RectangularSensor'],['../class_rectangular_sensor.html#a860b22f49c30a9e1194a4c3c9b593720',1,'RectangularSensor::RectangularSensor(Real angleWidthIn, Real angleHeightIn)'],['../class_rectangular_sensor.html#a5958b786fd2d9a05147ceb66672cd4a0',1,'RectangularSensor::RectangularSensor(const RectangularSensor &amp;copy)']]],
  ['rectangularsensor_2ecpp',['RectangularSensor.cpp',['../_rectangular_sensor_8cpp.html',1,'']]],
  ['rectangularsensor_2ehpp',['RectangularSensor.hpp',['../_rectangular_sensor_8hpp.html',1,'']]],
  ['refjd',['refJd',['../class_propagator.html#a150bc0c134ae5ee96f8f2de6c0707800',1,'Propagator']]],
  ['regionisfullycontained',['RegionIsFullyContained',['../class_custom_sensor.html#a0f3fb377ba3faf974bb7b2903b52d63e',1,'CustomSensor']]],
  ['rightascensionnoderate',['rightAscensionNodeRate',['../class_propagator.html#a474b8ffa17d2263aa15acdef1d1a4366',1,'Propagator']]],
  ['rotationresult',['rotationResult',['../class_earth.html#a9ea1e7b32d9be7fb70048654700cd035',1,'Earth']]]
];
