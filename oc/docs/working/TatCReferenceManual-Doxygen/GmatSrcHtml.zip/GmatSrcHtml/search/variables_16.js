var searchData=
[
  ['x',['x',['../class_lagrange_interpolator.html#a049cbd37bf00bf760008b0e37511b497',1,'LagrangeInterpolator']]],
  ['xtemp',['xtemp',['../structgeoparms.html#a57c627762c58aa43ae7cf12265da55c4',1,'geoparms']]]
];
