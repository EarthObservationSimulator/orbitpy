var searchData=
[
  ['baseexception',['BaseException',['../class_base_exception.html',1,'']]]
];
