var searchData=
[
  ['default_5fto_5fno_5fclones',['DEFAULT_TO_NO_CLONES',['../gmatdefs_8hpp.html#abb60cd4060d7c9044459df70538d89cb',1,'gmatdefs.hpp']]],
  ['default_5fto_5fno_5frefobjects',['DEFAULT_TO_NO_REFOBJECTS',['../gmatdefs_8hpp.html#a66a46e3419e5e4d270a0747d83746bbd',1,'gmatdefs.hpp']]]
];
