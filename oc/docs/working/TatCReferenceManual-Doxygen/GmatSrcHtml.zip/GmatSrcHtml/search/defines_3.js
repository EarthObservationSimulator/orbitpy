var searchData=
[
  ['num_5fdata_5finit',['NUM_DATA_INIT',['../_rvector6_8hpp.html#a32163ebf4c7e3c019573f31d8475177f',1,'Rvector6.hpp']]]
];
